package dropbox.msgs;

public record CreateFolderV2Args(String path, boolean autorename) {
}