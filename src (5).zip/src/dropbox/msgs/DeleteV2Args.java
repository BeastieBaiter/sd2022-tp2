package dropbox.msgs;

public record DeleteV2Args(String path) {
}
