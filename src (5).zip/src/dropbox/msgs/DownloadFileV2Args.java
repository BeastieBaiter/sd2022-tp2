package dropbox.msgs;

public record DownloadFileV2Args(String path) {
}