package dropbox.msgs;

public record ListFolderContinueArgs(String cursor) {
}
